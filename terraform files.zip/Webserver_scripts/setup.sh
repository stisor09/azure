#!/bin/bash

APP_DIR="/var/www/html/flask_app"

# Update system and install dependencies
sudo add-apt-repository universe -y
sudo apt-get update -y
sudo apt-get install -y nginx python3-flask python3-gunicorn gunicorn python3-mysql.connector
sudo apt-get update -y
sudo apt --fix-broken install

# Set up Flask application directory
sudo mkdir -p $APP_DIR/templates
sudo chown -R $USER:$USER $APP_DIR

# Copy Flask application and templates
sudo cp /tmp/app.py $APP_DIR/app.py
sudo cp /tmp/index.html $APP_DIR/templates/index.html

# Copy Gunicorn systemd service file
sudo cp /tmp/flask_app.service /etc/systemd/system/flask_app.service

# Start and enable Gunicorn service
sudo systemctl start flask_app
sudo systemctl enable flask_app

# Copy NGINX configuration and restart NGINX
sudo cp /tmp/flask_app.nginx /etc/nginx/sites-available/flask_app
sudo ln -s /etc/nginx/sites-available/flask_app /etc/nginx/sites-enabled
sudo rm /etc/nginx/sites-enabled/default
sudo systemctl restart nginx

sudo chmod 777 /var/www/html/flask_app				 # set permissions
sudo chown www-data:www-data /var/www/html/flask_app # Give www-data ownership
sudo chmod 766 /var/www/html/flask_app/flask_app.sock # writable sock
sudo systemctl daemon-reload
sudo systemctl restart flask_app
