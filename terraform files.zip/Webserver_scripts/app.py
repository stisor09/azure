import logging
from flask import Flask, render_template
import mysql.connector

logging.basicConfig(filename='/var/www/html/flask_app/flask_app.log', level=logging.DEBUG)

app = Flask(__name__)

@app.route("/")
def index():
    try:
        connection = mysql.connector.connect(
            host="10.0.2.4",  # MySQL load balancer
            user="stisor09",  # MySQL username
            password="Passord123",  # MySQL password
            database="mysql_database",  # Database
            port=3306  # MySQL port
        )
        cursor = connection.cursor()
        cursor.execute("SELECT * FROM your_table_name;")
        rows = cursor.fetchall()
        cursor.close()
        connection.close()
        return render_template("index.html", rows=rows)
    except Exception as e:
        logging.error(f"Error: {str(e)}")
        return f"Error: {str(e)}", 500

if __name__ == "__main__":
    app.run()
